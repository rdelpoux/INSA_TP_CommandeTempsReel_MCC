/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.38.
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: TPMCC_MCLV2_dsPIC33EP256MC506_V0_data.c
 *
 * Code generated for Simulink model 'TPMCC_MCLV2_dsPIC33EP256MC506_V0'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Tue Oct 02 17:38:21 2018
 */

#include "TPMCC_MCLV2_dsPIC33EP256MC506_V0.h"
#include "TPMCC_MCLV2_dsPIC33EP256MC506_V0_private.h"

/* Constant parameters (auto storage) */
const ConstP_TPMCC_MCLV2_dsPIC33EP256MC506_V0_T
  TPMCC_MCLV2_dsPIC33EP256MC506_V0_ConstP = {
  /* Computed Parameter: Reference_FormatString_Value
   * Referenced by: '<S14>/Reference_FormatString'
   */
  { 13, 27, 91, 55, 109, 32, 69, 110, 116, 114, 101, 114, 32, 108, 97, 32, 118,
    97, 108, 101, 117, 114, 32, 100, 101, 32, 108, 97, 32, 99, 111, 110, 115,
    105, 103, 110, 101, 32, 80, 114, 101, 115, 115, 32, 60, 69, 83, 67, 62, 32,
    116, 111, 32, 101, 120, 105, 116, 27, 91, 50, 55, 109, 0 },

  /* Expression: uint8([13 27 '[2K' 0])
   * Referenced by: '<S15>/Constant1'
   */
  { 13U, 27U, 91U, 50U, 75U, 0U },

  /* Pooled Parameter (Expression: [13 10])
   * Referenced by:
   *   '<S6>/cr lf'
   *   '<S14>/cr lf'
   */
  { 13U, 10U },

  /* Computed Parameter: FormatString_Value
   * Referenced by: '<S6>/FormatString '
   */
  { 37U, 115U, 0U }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
