function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/Communication */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:208"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:208";
	/* <Root>/Config MCLV2 - dsPIC33EP256MC506  */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:200"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:200";
	/* <Root>/Data Store
Memory */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:198"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_private.h:74";
	/* <Root>/Data Store
Read */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:199"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:49";
	/* <S1>/Compare
To Zero */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:209";
	/* <S1>/Digital Output */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:210";
	/* <S1>/Terminal Interface Management */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:211"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:97,542";
	/* <S1>/UART Rx */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:253"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:63&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:66,67";
	/* <S2>/Compiler Options */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:201"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:201";
	/* <S2>/Microchip Master */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:202"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:582,584";
	/* <S2>/Port Info */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:203"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:203";
	/* <S2>/Scheduler Options */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:204"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:204";
	/* <S2>/Simulink Reset
Config */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:205"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:205";
	/* <S2>/Timer Info */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:206"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:206";
	/* <S2>/UART Configuration1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:207"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:586&MCHP_UART1_Interrupt.c:4";
	/* <S3>/Gain */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:118"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:118";
	/* <S3>/Gain1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:119"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:119";
	/* <S3>/QEI1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:108"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:36,572&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:64,65";
	/* <S4>/u */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:1"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:1";
	/* <S4>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:89";
	/* <S4>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:90";
	/* <S4>/y */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:5"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:5";
	/* <S5>/In1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:71"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:71";
	/* <S5>/Digital Output
Write */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:4"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:94";
	/* <S6>/rxBuffer* */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:212"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:212";
	/* <S6>/rxCnt */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:213"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:213";
	/* <S6>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:214"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:98";
	/* <S6>/Add every bytes received to the buffer */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:215"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:101&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:68,74";
	/* <S6>/Clear current line - "ESC" pressed */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:216"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:110,177";
	/* <S6>/Clear terminal - "clear" command */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:222"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:464,539";
	/* <S6>/Compare
To Constant1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:231";
	/* <S6>/Compare 
To Constant1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:232";
	/* <S6>/Compare 
To Constant2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:233";
	/* <S6>/ESC */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:234";
	/* <S6>/FormatString
 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:235"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:180&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:99&TPMCC_MCLV2_dsPIC33EP256MC506_V0_data.c:49";
	/* <S6>/Print help - "help" command */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:236"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:285,346";
	/* <S6>/Print ref - "ref" command */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:241"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:348,462";
	/* <S6>/Print the current content of the output buffer */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:248"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:179&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:69";
	/* <S6>/UART Tx */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:249"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:191&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:75";
	/* <S6>/UART Tx2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:250"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:238";
	/* <S6>/cr lf */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:251"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:239&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:93&TPMCC_MCLV2_dsPIC33EP256MC506_V0_data.c:43";
	/* <S6>/Out1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:252"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:252";
	/* <S7>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:217"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:111";
	/* <S7>/Clear current line */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:218"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:118,173";
	/* <S8>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:223"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:465";
	/* <S8>/Mux */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:224"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:224";
	/* <S8>/Reset terminal */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:225"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:225";
	/* <S8>/Set cursor home */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:226"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:226";
	/* <S8>/UART Tx1
Send all */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:227"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:492";
	/* <S8>/termination */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:228"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:473";
	/* <S9>/u */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:1"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:1";
	/* <S9>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:467,538";
	/* <S9>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:468";
	/* <S9>/y */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:4"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:4";
	/* <S10>/u */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:1"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:1";
	/* <S10>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:351,461";
	/* <S10>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:352";
	/* <S10>/y */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:4"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:4";
	/* <S11>/u */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:1"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:1";
	/* <S11>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:288,345";
	/* <S11>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:289";
	/* <S11>/y */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:4"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:4";
	/* <S12>/u */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:1"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:1";
	/* <S12>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:113,176";
	/* <S12>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:114";
	/* <S12>/y */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:4"] = "msg=&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:4";
	/* <S13>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:237"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:286";
	/* <S13>/Help C Function Call */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:238"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:293&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:71";
	/* <S13>/UART Tx2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:239"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:298";
	/* <S14>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:242"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:349";
	/* <S14>/Print the current content of the output buffer */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:243"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:356&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:70";
	/* <S14>/Reference_FormatString */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:244"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:357&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:82&TPMCC_MCLV2_dsPIC33EP256MC506_V0_data.c:29";
	/* <S14>/UART Tx */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:245"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:366&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:76";
	/* <S14>/UART Tx2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:246"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:413";
	/* <S14>/cr lf */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:247"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:414&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:94&TPMCC_MCLV2_dsPIC33EP256MC506_V0_data.c:44";
	/* <S15>/C Function Call2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:219"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:120&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:73";
	/* <S15>/Constant1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:220"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:121&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:87&TPMCC_MCLV2_dsPIC33EP256MC506_V0_data.c:37";
	/* <S15>/UART Tx1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:221"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:128";
	/* <S16>/PWM High Speed */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:103"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:544,557";
	/* <S16>/Saturation */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:104"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:53,62&TPMCC_MCLV2_dsPIC33EP256MC506_V0.h:63";
	/* <S16>/int to uint */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:105"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:105";
	/* <S17>/Data Type Conversion */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:124"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:124";
	/* <S17>/Delay */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:125"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:125";
	/* <S17>/Gain */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:126"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:126";
	/* <S17>/Gain1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:127"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:127";
	/* <S17>/Gain2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:128"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:128";
	/* <S17>/Sum */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:129"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:129";
	/* <S17>/Sum1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:130"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0:130";
	/* <S18>/Gain */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:90"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0.c:48";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:208"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:208"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:200"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:200"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:166"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:166"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:209"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:210"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:211"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:211"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S7>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:216"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:216"] = {rtwname: "<S7>"};
	this.rtwnameHashMap["<S8>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:222"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:222"] = {rtwname: "<S8>"};
	this.rtwnameHashMap["<S9>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:231"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231"] = {rtwname: "<S9>"};
	this.rtwnameHashMap["<S10>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:232"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232"] = {rtwname: "<S10>"};
	this.rtwnameHashMap["<S11>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:233"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233"] = {rtwname: "<S11>"};
	this.rtwnameHashMap["<S12>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:234"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234"] = {rtwname: "<S12>"};
	this.rtwnameHashMap["<S13>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:236"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:236"] = {rtwname: "<S13>"};
	this.rtwnameHashMap["<S14>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:241"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:241"] = {rtwname: "<S14>"};
	this.rtwnameHashMap["<S15>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:218"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:218"] = {rtwname: "<S15>"};
	this.rtwnameHashMap["<S16>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:92"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:92"] = {rtwname: "<S16>"};
	this.rtwnameHashMap["<S17>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:122"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:122"] = {rtwname: "<S17>"};
	this.rtwnameHashMap["<S18>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:86"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:86"] = {rtwname: "<S18>"};
	this.rtwnameHashMap["<Root>/Communication"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:208"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:208"] = {rtwname: "<Root>/Communication"};
	this.rtwnameHashMap["<Root>/Config MCLV2 - dsPIC33EP256MC506 "] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:200"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:200"] = {rtwname: "<Root>/Config MCLV2 - dsPIC33EP256MC506 "};
	this.rtwnameHashMap["<Root>/Data Store Memory"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:198"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:198"] = {rtwname: "<Root>/Data Store Memory"};
	this.rtwnameHashMap["<Root>/Data Store Read"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:199"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:199"] = {rtwname: "<Root>/Data Store Read"};
	this.rtwnameHashMap["<Root>/Moteur"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:166"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:166"] = {rtwname: "<Root>/Moteur"};
	this.rtwnameHashMap["<S1>/Compare To Zero"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:209"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209"] = {rtwname: "<S1>/Compare To Zero"};
	this.rtwnameHashMap["<S1>/Digital Output"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:210"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210"] = {rtwname: "<S1>/Digital Output"};
	this.rtwnameHashMap["<S1>/Terminal Interface Management"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:211"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:211"] = {rtwname: "<S1>/Terminal Interface Management"};
	this.rtwnameHashMap["<S1>/UART Rx"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:253"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:253"] = {rtwname: "<S1>/UART Rx"};
	this.rtwnameHashMap["<S2>/Compiler Options"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:201"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:201"] = {rtwname: "<S2>/Compiler Options"};
	this.rtwnameHashMap["<S2>/Microchip Master"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:202"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:202"] = {rtwname: "<S2>/Microchip Master"};
	this.rtwnameHashMap["<S2>/Port Info"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:203"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:203"] = {rtwname: "<S2>/Port Info"};
	this.rtwnameHashMap["<S2>/Scheduler Options"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:204"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:204"] = {rtwname: "<S2>/Scheduler Options"};
	this.rtwnameHashMap["<S2>/Simulink Reset Config"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:205"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:205"] = {rtwname: "<S2>/Simulink Reset Config"};
	this.rtwnameHashMap["<S2>/Timer Info"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:206"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:206"] = {rtwname: "<S2>/Timer Info"};
	this.rtwnameHashMap["<S2>/UART Configuration1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:207"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:207"] = {rtwname: "<S2>/UART Configuration1"};
	this.rtwnameHashMap["<S3>/v (tension en V)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:167"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:167"] = {rtwname: "<S3>/v (tension en V)"};
	this.rtwnameHashMap["<S3>/Gain"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:118"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:118"] = {rtwname: "<S3>/Gain"};
	this.rtwnameHashMap["<S3>/Gain1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:119"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:119"] = {rtwname: "<S3>/Gain1"};
	this.rtwnameHashMap["<S3>/PWM"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:92"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:92"] = {rtwname: "<S3>/PWM"};
	this.rtwnameHashMap["<S3>/QEI1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:108"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:108"] = {rtwname: "<S3>/QEI1"};
	this.rtwnameHashMap["<S3>/Subsystem2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:122"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:122"] = {rtwname: "<S3>/Subsystem2"};
	this.rtwnameHashMap["<S3>/Position (rad)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:168"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:168"] = {rtwname: "<S3>/Position (rad)"};
	this.rtwnameHashMap["<S3>/Vitesse (rad//sec)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:169"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:169"] = {rtwname: "<S3>/Vitesse (rad//sec)"};
	this.rtwnameHashMap["<S4>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:1"] = {rtwname: "<S4>/u"};
	this.rtwnameHashMap["<S4>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:2"] = {rtwname: "<S4>/Compare"};
	this.rtwnameHashMap["<S4>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:3"] = {rtwname: "<S4>/Constant"};
	this.rtwnameHashMap["<S4>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:5"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:209:5"] = {rtwname: "<S4>/y"};
	this.rtwnameHashMap["<S5>/In1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:71"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:71"] = {rtwname: "<S5>/In1"};
	this.rtwnameHashMap["<S5>/Digital Output Write"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:210:4"] = {rtwname: "<S5>/Digital Output Write"};
	this.rtwnameHashMap["<S6>/rxBuffer*"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:212"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:212"] = {rtwname: "<S6>/rxBuffer*"};
	this.rtwnameHashMap["<S6>/rxCnt"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:213"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:213"] = {rtwname: "<S6>/rxCnt"};
	this.rtwnameHashMap["<S6>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:214"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:214"] = {rtwname: "<S6>/Enable"};
	this.rtwnameHashMap["<S6>/Add every bytes received to the buffer"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:215"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:215"] = {rtwname: "<S6>/Add every bytes received to the buffer"};
	this.rtwnameHashMap["<S6>/Clear current line - \"ESC\" pressed"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:216"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:216"] = {rtwname: "<S6>/Clear current line - \"ESC\" pressed"};
	this.rtwnameHashMap["<S6>/Clear terminal - \"clear\" command"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:222"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:222"] = {rtwname: "<S6>/Clear terminal - \"clear\" command"};
	this.rtwnameHashMap["<S6>/Compare To Constant1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:231"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231"] = {rtwname: "<S6>/Compare To Constant1"};
	this.rtwnameHashMap["<S6>/Compare  To Constant1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:232"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232"] = {rtwname: "<S6>/Compare  To Constant1"};
	this.rtwnameHashMap["<S6>/Compare  To Constant2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:233"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233"] = {rtwname: "<S6>/Compare  To Constant2"};
	this.rtwnameHashMap["<S6>/ESC"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:234"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234"] = {rtwname: "<S6>/ESC"};
	this.rtwnameHashMap["<S6>/FormatString "] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:235"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:235"] = {rtwname: "<S6>/FormatString "};
	this.rtwnameHashMap["<S6>/Print help - \"help\" command"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:236"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:236"] = {rtwname: "<S6>/Print help - \"help\" command"};
	this.rtwnameHashMap["<S6>/Print ref - \"ref\" command"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:241"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:241"] = {rtwname: "<S6>/Print ref - \"ref\" command"};
	this.rtwnameHashMap["<S6>/Print the current content of the output buffer"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:248"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:248"] = {rtwname: "<S6>/Print the current content of the output buffer"};
	this.rtwnameHashMap["<S6>/UART Tx"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:249"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:249"] = {rtwname: "<S6>/UART Tx"};
	this.rtwnameHashMap["<S6>/UART Tx2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:250"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:250"] = {rtwname: "<S6>/UART Tx2"};
	this.rtwnameHashMap["<S6>/cr lf"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:251"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:251"] = {rtwname: "<S6>/cr lf"};
	this.rtwnameHashMap["<S6>/Out1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:252"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:252"] = {rtwname: "<S6>/Out1"};
	this.rtwnameHashMap["<S7>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:217"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:217"] = {rtwname: "<S7>/Enable"};
	this.rtwnameHashMap["<S7>/Clear current line"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:218"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:218"] = {rtwname: "<S7>/Clear current line"};
	this.rtwnameHashMap["<S8>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:223"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:223"] = {rtwname: "<S8>/Enable"};
	this.rtwnameHashMap["<S8>/Mux"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:224"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:224"] = {rtwname: "<S8>/Mux"};
	this.rtwnameHashMap["<S8>/Reset terminal"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:225"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:225"] = {rtwname: "<S8>/Reset terminal"};
	this.rtwnameHashMap["<S8>/Set cursor home"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:226"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:226"] = {rtwname: "<S8>/Set cursor home"};
	this.rtwnameHashMap["<S8>/UART Tx1 Send all"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:227"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:227"] = {rtwname: "<S8>/UART Tx1 Send all"};
	this.rtwnameHashMap["<S8>/termination"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:228"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:228"] = {rtwname: "<S8>/termination"};
	this.rtwnameHashMap["<S9>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:1"] = {rtwname: "<S9>/u"};
	this.rtwnameHashMap["<S9>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:2"] = {rtwname: "<S9>/Compare"};
	this.rtwnameHashMap["<S9>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:3"] = {rtwname: "<S9>/Constant"};
	this.rtwnameHashMap["<S9>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:231:4"] = {rtwname: "<S9>/y"};
	this.rtwnameHashMap["<S10>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:1"] = {rtwname: "<S10>/u"};
	this.rtwnameHashMap["<S10>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:2"] = {rtwname: "<S10>/Compare"};
	this.rtwnameHashMap["<S10>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:3"] = {rtwname: "<S10>/Constant"};
	this.rtwnameHashMap["<S10>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:232:4"] = {rtwname: "<S10>/y"};
	this.rtwnameHashMap["<S11>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:1"] = {rtwname: "<S11>/u"};
	this.rtwnameHashMap["<S11>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:2"] = {rtwname: "<S11>/Compare"};
	this.rtwnameHashMap["<S11>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:3"] = {rtwname: "<S11>/Constant"};
	this.rtwnameHashMap["<S11>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:233:4"] = {rtwname: "<S11>/y"};
	this.rtwnameHashMap["<S12>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:1"] = {rtwname: "<S12>/u"};
	this.rtwnameHashMap["<S12>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:2"] = {rtwname: "<S12>/Compare"};
	this.rtwnameHashMap["<S12>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:3"] = {rtwname: "<S12>/Constant"};
	this.rtwnameHashMap["<S12>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:234:4"] = {rtwname: "<S12>/y"};
	this.rtwnameHashMap["<S13>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:237"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:237"] = {rtwname: "<S13>/Enable"};
	this.rtwnameHashMap["<S13>/Help C Function Call"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:238"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:238"] = {rtwname: "<S13>/Help C Function Call"};
	this.rtwnameHashMap["<S13>/UART Tx2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:239"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:239"] = {rtwname: "<S13>/UART Tx2"};
	this.rtwnameHashMap["<S14>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:242"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:242"] = {rtwname: "<S14>/Enable"};
	this.rtwnameHashMap["<S14>/Print the current content of the output buffer"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:243"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:243"] = {rtwname: "<S14>/Print the current content of the output buffer"};
	this.rtwnameHashMap["<S14>/Reference_FormatString"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:244"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:244"] = {rtwname: "<S14>/Reference_FormatString"};
	this.rtwnameHashMap["<S14>/UART Tx"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:245"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:245"] = {rtwname: "<S14>/UART Tx"};
	this.rtwnameHashMap["<S14>/UART Tx2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:246"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:246"] = {rtwname: "<S14>/UART Tx2"};
	this.rtwnameHashMap["<S14>/cr lf"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:247"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:247"] = {rtwname: "<S14>/cr lf"};
	this.rtwnameHashMap["<S15>/C Function Call2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:219"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:219"] = {rtwname: "<S15>/C Function Call2"};
	this.rtwnameHashMap["<S15>/Constant1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:220"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:220"] = {rtwname: "<S15>/Constant1"};
	this.rtwnameHashMap["<S15>/UART Tx1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:221"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:221"] = {rtwname: "<S15>/UART Tx1"};
	this.rtwnameHashMap["<S16>/Vdc"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:93"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:93"] = {rtwname: "<S16>/Vdc"};
	this.rtwnameHashMap["<S16>/MLI"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:86"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:86"] = {rtwname: "<S16>/MLI"};
	this.rtwnameHashMap["<S16>/PWM High Speed"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:103"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:103"] = {rtwname: "<S16>/PWM High Speed"};
	this.rtwnameHashMap["<S16>/Saturation"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:104"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:104"] = {rtwname: "<S16>/Saturation"};
	this.rtwnameHashMap["<S16>/int to uint"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:105"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:105"] = {rtwname: "<S16>/int to uint"};
	this.rtwnameHashMap["<S17>/om(rad//s)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:123"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:123"] = {rtwname: "<S17>/om(rad//s)"};
	this.rtwnameHashMap["<S17>/Data Type Conversion"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:124"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:124"] = {rtwname: "<S17>/Data Type Conversion"};
	this.rtwnameHashMap["<S17>/Delay"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:125"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:125"] = {rtwname: "<S17>/Delay"};
	this.rtwnameHashMap["<S17>/Gain"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:126"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:126"] = {rtwname: "<S17>/Gain"};
	this.rtwnameHashMap["<S17>/Gain1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:127"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:127"] = {rtwname: "<S17>/Gain1"};
	this.rtwnameHashMap["<S17>/Gain2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:128"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:128"] = {rtwname: "<S17>/Gain2"};
	this.rtwnameHashMap["<S17>/Sum"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:129"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:129"] = {rtwname: "<S17>/Sum"};
	this.rtwnameHashMap["<S17>/Sum1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:130"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:130"] = {rtwname: "<S17>/Sum1"};
	this.rtwnameHashMap["<S17>/omf (rad//s)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:131"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:131"] = {rtwname: "<S17>/omf (rad//s)"};
	this.rtwnameHashMap["<S18>/Vdc"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:87"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:87"] = {rtwname: "<S18>/Vdc"};
	this.rtwnameHashMap["<S18>/Gain"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:90"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:90"] = {rtwname: "<S18>/Gain"};
	this.rtwnameHashMap["<S18>/PWM [0 PWMmax]"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0:91"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0:91"] = {rtwname: "<S18>/PWM [0 PWMmax]"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
