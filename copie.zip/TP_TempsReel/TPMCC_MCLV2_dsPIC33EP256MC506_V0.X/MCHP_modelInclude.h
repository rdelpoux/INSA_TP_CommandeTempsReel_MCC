/******************************************************/
/* This file includes simulink model public .h files. */
/* File name will not depends on model's name 	      */
/* simplifying inclusion for your shared c/h added    */
/* code (if any)  	                                  */
/******************************************************/

#include "TPMCC_MCLV2_dsPIC33EP256MC506_V0.h"
#include "TPMCC_MCLV2_dsPIC33EP256MC506_V0_private.h"
