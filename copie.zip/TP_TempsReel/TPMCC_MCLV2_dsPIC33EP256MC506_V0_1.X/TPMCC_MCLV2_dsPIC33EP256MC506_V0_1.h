/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.38.
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h
 *
 * Code generated for Simulink model 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Oct 04 15:29:59 2018
 */

#ifndef RTW_HEADER_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_h_
#define RTW_HEADER_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_h_
#include <string.h>
#include <stddef.h>
#ifndef TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_COMMON_INCLUDES_
# define TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_COMMON_INCLUDES_ */

#include "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_types.h"
#define FCY                            (64000000U)               /* Instruction Frequency FCY set at  64.0 MHz */

/* Include for pic 33E */
#include <p33Exxxx.h>
#include <libpic30.h>                  /* For possible use with C function Call block (delay_ms or delay_us functions might be used by few peripherals) */
#include <libq.h>                      /* For possible use with C function Call block */

/* Macros for accessing real-time model data structure */
#ifndef rtmCounterLimit
# define rtmCounterLimit(rtm, idx)     ((rtm)->Timing.TaskCounters.cLimit[(idx)])
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Declare UART1 Tx Circular Buffer Structure */
#define Tx_BUFF_SIZE_Uart1             (2048)

typedef struct MCHP_UART1_TxStr{
  volatile uint8_T buffer[Tx_BUFF_SIZE_Uart1];/* Size Rx_BUFF_SIZE_Uart1 is 2048 */
  volatile uint_T tail;                /* tail is the index for the next value to be read from the Circular buffer */
  volatile uint_T head;                /* head is the index for the next value to be written into the Circular buffer */
} MCHP_UART1_TxStr;

/* Block signals and states (auto storage) for system '<Root>' */
typedef struct {
  uint16_T Saturation;                 /* '<S16>/Saturation' */
  uint16_T Saturation2;                /* '<S16>/Saturation2' */
  uint16_T U1CH1;                      /* '<S3>/QEI1' */
  uint16_T U1CH2;                      /* '<S3>/QEI1' */
  uint16_T U1Rx;                       /* '<S1>/UART Rx' */
  uint8_T U1Rx_m[100];                 /* '<S1>/UART Rx' */
  uint8_T Addeverybytesreceivedtothebuffer_o2[100];/* '<S6>/Add every bytes received to the buffer' */
  uint8_T Printthecurrentcontentoftheoutputbuffer[100];/* '<S6>/Print the current content of the output buffer' */
  uint8_T Printthecurrentcontentoftheoutputbuffer_g[100];/* '<S14>/Print the current content of the output buffer' */
  uint8_T HelpCFunctionCall[5000];     /* '<S13>/Help C Function Call' */
  uint8_T TmpSignalConversionAtUARTTx1SendallInport1[8];
  uint8_T CFunctionCall2[100];         /* '<S15>/C Function Call2' */
  uint8_T Addeverybytesreceivedtothebuffer_o1;/* '<S6>/Add every bytes received to the buffer' */
  boolean_T fakedatalinkNothinghere;   /* '<S6>/UART Tx' */
  boolean_T fakedatalinkNothinghere_i; /* '<S14>/UART Tx' */
} DW_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_T;

/* Constant parameters (auto storage) */
typedef struct {
  /* Computed Parameter: Reference_FormatString_Value
   * Referenced by: '<S14>/Reference_FormatString'
   */
  int8_T Reference_FormatString_Value[63];

  /* Expression: uint8([13 27 '[2K' 0])
   * Referenced by: '<S15>/Constant1'
   */
  uint8_T Constant1_Value[6];

  /* Pooled Parameter (Expression: [13 10])
   * Referenced by:
   *   '<S6>/cr lf'
   *   '<S14>/cr lf'
   */
  uint8_T pooled4[2];

  /* Computed Parameter: FormatString_Value
   * Referenced by: '<S6>/FormatString '
   */
  uint8_T FormatString_Value[3];
} ConstP_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_T;

/* Real-time Model Data Structure */
struct tag_RTM_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_T {
  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[2];
      uint8_T cLimit[2];
    } TaskCounters;
  } Timing;
};

/* Block signals and states (auto storage) */
extern DW_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_T
  TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_DW;

/* Constant parameters (auto storage) */
extern const ConstP_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_T
  TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_ConstP;

/* Model entry point functions */
extern void TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_initialize(void);
extern void TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_step0(void);
extern void TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_step1(void);

/* Real-time Model object */
extern RT_MODEL_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_T *const
  TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Gain' : Unused code path elimination
 * Block '<S3>/Gain1' : Unused code path elimination
 * Block '<S17>/Data Type Conversion' : Unused code path elimination
 * Block '<S17>/Delay' : Unused code path elimination
 * Block '<S17>/Gain' : Unused code path elimination
 * Block '<S17>/Gain1' : Unused code path elimination
 * Block '<S17>/Gain2' : Unused code path elimination
 * Block '<S17>/Sum' : Unused code path elimination
 * Block '<S17>/Sum1' : Unused code path elimination
 * Block '<S16>/int to uint' : Eliminate redundant data type conversion
 * Block '<S16>/int to uint1' : Eliminate redundant data type conversion
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1'
 * '<S1>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication'
 * '<S2>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Config MCLV2 - dsPIC33EP256MC506 '
 * '<S3>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Moteur'
 * '<S4>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Compare To Zero'
 * '<S5>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Digital Output'
 * '<S6>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management'
 * '<S7>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Clear current line - "ESC" pressed'
 * '<S8>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Clear terminal - "clear" command'
 * '<S9>'   : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Compare To Constant1'
 * '<S10>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Compare  To Constant1'
 * '<S11>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Compare  To Constant2'
 * '<S12>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/ESC'
 * '<S13>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Print help - "help" command'
 * '<S14>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Print ref - "ref" command'
 * '<S15>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Communication/Terminal Interface Management/Clear current line - "ESC" pressed/Clear current line'
 * '<S16>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Moteur/PWM'
 * '<S17>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Moteur/Subsystem2'
 * '<S18>'  : 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1/Moteur/PWM/MLI'
 */
#endif                                 /* RTW_HEADER_TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
