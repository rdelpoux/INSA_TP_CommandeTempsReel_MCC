/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.38.
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: rtmodel.h
 *
 * Code generated for Simulink model 'TPMCC_MCLV2_dsPIC33EP256MC506_V0_1'.
 *
 * Model version                  : 1.10
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Oct 04 15:29:59 2018
 */

#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h"

/* Macros generated for backwards compatibility  */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        (NULL)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   (NULL)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif
#endif                                 /* RTW_HEADER_rtmodel_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
