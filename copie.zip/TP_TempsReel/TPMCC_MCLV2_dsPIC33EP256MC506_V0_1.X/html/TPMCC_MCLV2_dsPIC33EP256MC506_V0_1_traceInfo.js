function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/Data Store
Memory */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:198"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_private.h:74";
	/* <Root>/Data Store
Read */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:199"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:51";
	/* <S1>/Terminal Interface Management */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:211"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:125,571";
	/* <S1>/UART Rx */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:253"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:91&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:67,68";
	/* <S2>/Compiler Options */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:201"] = "msg=rtwMsg_notTraceable&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:201";
	/* <S2>/Microchip Master */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:202"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:617,619";
	/* <S2>/Port Info */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:203"] = "msg=rtwMsg_notTraceable&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:203";
	/* <S2>/Scheduler Options */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:204"] = "msg=rtwMsg_notTraceable&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:204";
	/* <S2>/Simulink Reset
Config */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:205"] = "msg=rtwMsg_notTraceable&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:205";
	/* <S2>/Timer Info */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:206"] = "msg=rtwMsg_notTraceable&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:206";
	/* <S2>/UART Configuration1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:207"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:621&MCHP_UART1_Interrupt.c:4";
	/* <S3>/Gain */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:118"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:118";
	/* <S3>/Gain1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:119"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:119";
	/* <S3>/QEI1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:108"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:37,607&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:65,66";
	/* <S4>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:117";
	/* <S4>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:118";
	/* <S5>/Digital Output
Write */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210:4"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:122";
	/* <S6>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:214"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:126";
	/* <S6>/Add every bytes received to the buffer */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:215"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:129&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:69,75";
	/* <S6>/Clear current line - "ESC" pressed */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:216"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:138,206";
	/* <S6>/Clear terminal - "clear" command */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:222"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:493,568";
	/* <S6>/FormatString
 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:235"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:209&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:100&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_data.c:49";
	/* <S6>/Print help - "help" command */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:236"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:314,375";
	/* <S6>/Print ref - "ref" command */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:241"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:377,491";
	/* <S6>/Print the current content of the output buffer */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:248"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:208&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:70";
	/* <S6>/UART Tx */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:249"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:220&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:76";
	/* <S6>/UART Tx2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:250"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:267";
	/* <S6>/cr lf */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:251"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:268&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:94&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_data.c:43";
	/* <S7>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:217"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:139";
	/* <S7>/Clear current line */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:218"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:146,202";
	/* <S8>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:223"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:494";
	/* <S8>/Reset terminal */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:225"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:225";
	/* <S8>/Set cursor home */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:226"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:226";
	/* <S8>/UART Tx1
Send all */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:227"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:521";
	/* <S8>/termination */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:228"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:502";
	/* <S9>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:496,567";
	/* <S9>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:497";
	/* <S10>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:380,490";
	/* <S10>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:381";
	/* <S11>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:317,374";
	/* <S11>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:318";
	/* <S12>/Compare */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:2"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:141,205";
	/* <S12>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:3"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:142";
	/* <S13>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:237"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:315";
	/* <S13>/Help C Function Call */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:238"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:322&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:72";
	/* <S13>/UART Tx2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:239"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:327";
	/* <S14>/Enable */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:242"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:378";
	/* <S14>/Print the current content of the output buffer */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:243"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:385&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:71";
	/* <S14>/Reference_FormatString */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:244"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:386&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:83&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_data.c:29";
	/* <S14>/UART Tx */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:245"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:395&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:77";
	/* <S14>/UART Tx2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:246"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:442";
	/* <S14>/cr lf */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:247"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:443&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:95&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_data.c:44";
	/* <S15>/C Function Call2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:219"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:148&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:74";
	/* <S15>/Constant1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:220"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:149&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:88&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1_data.c:37";
	/* <S15>/UART Tx1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:221"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:156";
	/* <S16>/Constant */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:260"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:79";
	/* <S16>/PWM High Speed */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:103"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:573,587";
	/* <S16>/Saturation */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:104"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:69,76&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:63";
	/* <S16>/Saturation1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:257"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:50,61";
	/* <S16>/Saturation2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:258"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:83,90&TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.h:64";
	/* <S16>/Sum */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:261"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:78";
	/* <S16>/int to uint */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:105"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:105";
	/* <S16>/int to uint1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:259"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:259";
	/* <S17>/Data Type Conversion */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:124"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:124";
	/* <S17>/Delay */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:125"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:125";
	/* <S17>/Gain */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:126"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:126";
	/* <S17>/Gain1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:127"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:127";
	/* <S17>/Gain2 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:128"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:128";
	/* <S17>/Sum */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:129"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:129";
	/* <S17>/Sum1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:130"] = "msg=rtwMsg_reducedBlock&block=TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:130";
	/* <S18>/Bias */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:255"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:64";
	/* <S18>/Gain */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:90"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:63";
	/* <S18>/Gain1 */
	this.urlHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:256"] = "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1.c:65";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:208"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:208"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:200"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:200"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:166"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:166"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S5>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210"] = {rtwname: "<S5>"};
	this.rtwnameHashMap["<S6>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:211"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:211"] = {rtwname: "<S6>"};
	this.rtwnameHashMap["<S7>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:216"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:216"] = {rtwname: "<S7>"};
	this.rtwnameHashMap["<S8>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:222"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:222"] = {rtwname: "<S8>"};
	this.rtwnameHashMap["<S9>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231"] = {rtwname: "<S9>"};
	this.rtwnameHashMap["<S10>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232"] = {rtwname: "<S10>"};
	this.rtwnameHashMap["<S11>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233"] = {rtwname: "<S11>"};
	this.rtwnameHashMap["<S12>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234"] = {rtwname: "<S12>"};
	this.rtwnameHashMap["<S13>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:236"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:236"] = {rtwname: "<S13>"};
	this.rtwnameHashMap["<S14>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:241"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:241"] = {rtwname: "<S14>"};
	this.rtwnameHashMap["<S15>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:218"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:218"] = {rtwname: "<S15>"};
	this.rtwnameHashMap["<S16>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:92"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:92"] = {rtwname: "<S16>"};
	this.rtwnameHashMap["<S17>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:122"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:122"] = {rtwname: "<S17>"};
	this.rtwnameHashMap["<S18>"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:86"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:86"] = {rtwname: "<S18>"};
	this.rtwnameHashMap["<Root>/Communication"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:208"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:208"] = {rtwname: "<Root>/Communication"};
	this.rtwnameHashMap["<Root>/Config MCLV2 - dsPIC33EP256MC506 "] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:200"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:200"] = {rtwname: "<Root>/Config MCLV2 - dsPIC33EP256MC506 "};
	this.rtwnameHashMap["<Root>/Data Store Memory"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:198"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:198"] = {rtwname: "<Root>/Data Store Memory"};
	this.rtwnameHashMap["<Root>/Data Store Read"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:199"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:199"] = {rtwname: "<Root>/Data Store Read"};
	this.rtwnameHashMap["<Root>/Moteur"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:166"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:166"] = {rtwname: "<Root>/Moteur"};
	this.rtwnameHashMap["<S1>/Compare To Zero"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209"] = {rtwname: "<S1>/Compare To Zero"};
	this.rtwnameHashMap["<S1>/Digital Output"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210"] = {rtwname: "<S1>/Digital Output"};
	this.rtwnameHashMap["<S1>/Terminal Interface Management"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:211"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:211"] = {rtwname: "<S1>/Terminal Interface Management"};
	this.rtwnameHashMap["<S1>/UART Rx"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:253"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:253"] = {rtwname: "<S1>/UART Rx"};
	this.rtwnameHashMap["<S2>/Compiler Options"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:201"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:201"] = {rtwname: "<S2>/Compiler Options"};
	this.rtwnameHashMap["<S2>/Microchip Master"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:202"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:202"] = {rtwname: "<S2>/Microchip Master"};
	this.rtwnameHashMap["<S2>/Port Info"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:203"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:203"] = {rtwname: "<S2>/Port Info"};
	this.rtwnameHashMap["<S2>/Scheduler Options"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:204"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:204"] = {rtwname: "<S2>/Scheduler Options"};
	this.rtwnameHashMap["<S2>/Simulink Reset Config"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:205"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:205"] = {rtwname: "<S2>/Simulink Reset Config"};
	this.rtwnameHashMap["<S2>/Timer Info"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:206"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:206"] = {rtwname: "<S2>/Timer Info"};
	this.rtwnameHashMap["<S2>/UART Configuration1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:207"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:207"] = {rtwname: "<S2>/UART Configuration1"};
	this.rtwnameHashMap["<S3>/v (tension en V)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:167"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:167"] = {rtwname: "<S3>/v (tension en V)"};
	this.rtwnameHashMap["<S3>/Gain"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:118"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:118"] = {rtwname: "<S3>/Gain"};
	this.rtwnameHashMap["<S3>/Gain1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:119"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:119"] = {rtwname: "<S3>/Gain1"};
	this.rtwnameHashMap["<S3>/PWM"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:92"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:92"] = {rtwname: "<S3>/PWM"};
	this.rtwnameHashMap["<S3>/QEI1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:108"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:108"] = {rtwname: "<S3>/QEI1"};
	this.rtwnameHashMap["<S3>/Subsystem2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:122"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:122"] = {rtwname: "<S3>/Subsystem2"};
	this.rtwnameHashMap["<S3>/Position (rad)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:168"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:168"] = {rtwname: "<S3>/Position (rad)"};
	this.rtwnameHashMap["<S3>/Vitesse (rad//sec)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:169"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:169"] = {rtwname: "<S3>/Vitesse (rad//sec)"};
	this.rtwnameHashMap["<S4>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:1"] = {rtwname: "<S4>/u"};
	this.rtwnameHashMap["<S4>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:2"] = {rtwname: "<S4>/Compare"};
	this.rtwnameHashMap["<S4>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:3"] = {rtwname: "<S4>/Constant"};
	this.rtwnameHashMap["<S4>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:5"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:209:5"] = {rtwname: "<S4>/y"};
	this.rtwnameHashMap["<S5>/In1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210:71"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210:71"] = {rtwname: "<S5>/In1"};
	this.rtwnameHashMap["<S5>/Digital Output Write"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:210:4"] = {rtwname: "<S5>/Digital Output Write"};
	this.rtwnameHashMap["<S6>/rxBuffer*"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:212"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:212"] = {rtwname: "<S6>/rxBuffer*"};
	this.rtwnameHashMap["<S6>/rxCnt"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:213"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:213"] = {rtwname: "<S6>/rxCnt"};
	this.rtwnameHashMap["<S6>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:214"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:214"] = {rtwname: "<S6>/Enable"};
	this.rtwnameHashMap["<S6>/Add every bytes received to the buffer"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:215"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:215"] = {rtwname: "<S6>/Add every bytes received to the buffer"};
	this.rtwnameHashMap["<S6>/Clear current line - \"ESC\" pressed"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:216"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:216"] = {rtwname: "<S6>/Clear current line - \"ESC\" pressed"};
	this.rtwnameHashMap["<S6>/Clear terminal - \"clear\" command"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:222"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:222"] = {rtwname: "<S6>/Clear terminal - \"clear\" command"};
	this.rtwnameHashMap["<S6>/Compare To Constant1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231"] = {rtwname: "<S6>/Compare To Constant1"};
	this.rtwnameHashMap["<S6>/Compare  To Constant1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232"] = {rtwname: "<S6>/Compare  To Constant1"};
	this.rtwnameHashMap["<S6>/Compare  To Constant2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233"] = {rtwname: "<S6>/Compare  To Constant2"};
	this.rtwnameHashMap["<S6>/ESC"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234"] = {rtwname: "<S6>/ESC"};
	this.rtwnameHashMap["<S6>/FormatString "] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:235"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:235"] = {rtwname: "<S6>/FormatString "};
	this.rtwnameHashMap["<S6>/Print help - \"help\" command"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:236"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:236"] = {rtwname: "<S6>/Print help - \"help\" command"};
	this.rtwnameHashMap["<S6>/Print ref - \"ref\" command"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:241"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:241"] = {rtwname: "<S6>/Print ref - \"ref\" command"};
	this.rtwnameHashMap["<S6>/Print the current content of the output buffer"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:248"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:248"] = {rtwname: "<S6>/Print the current content of the output buffer"};
	this.rtwnameHashMap["<S6>/UART Tx"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:249"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:249"] = {rtwname: "<S6>/UART Tx"};
	this.rtwnameHashMap["<S6>/UART Tx2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:250"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:250"] = {rtwname: "<S6>/UART Tx2"};
	this.rtwnameHashMap["<S6>/cr lf"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:251"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:251"] = {rtwname: "<S6>/cr lf"};
	this.rtwnameHashMap["<S6>/Out1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:252"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:252"] = {rtwname: "<S6>/Out1"};
	this.rtwnameHashMap["<S7>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:217"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:217"] = {rtwname: "<S7>/Enable"};
	this.rtwnameHashMap["<S7>/Clear current line"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:218"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:218"] = {rtwname: "<S7>/Clear current line"};
	this.rtwnameHashMap["<S8>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:223"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:223"] = {rtwname: "<S8>/Enable"};
	this.rtwnameHashMap["<S8>/Mux"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:224"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:224"] = {rtwname: "<S8>/Mux"};
	this.rtwnameHashMap["<S8>/Reset terminal"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:225"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:225"] = {rtwname: "<S8>/Reset terminal"};
	this.rtwnameHashMap["<S8>/Set cursor home"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:226"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:226"] = {rtwname: "<S8>/Set cursor home"};
	this.rtwnameHashMap["<S8>/UART Tx1 Send all"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:227"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:227"] = {rtwname: "<S8>/UART Tx1 Send all"};
	this.rtwnameHashMap["<S8>/termination"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:228"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:228"] = {rtwname: "<S8>/termination"};
	this.rtwnameHashMap["<S9>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:1"] = {rtwname: "<S9>/u"};
	this.rtwnameHashMap["<S9>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:2"] = {rtwname: "<S9>/Compare"};
	this.rtwnameHashMap["<S9>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:3"] = {rtwname: "<S9>/Constant"};
	this.rtwnameHashMap["<S9>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:231:4"] = {rtwname: "<S9>/y"};
	this.rtwnameHashMap["<S10>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:1"] = {rtwname: "<S10>/u"};
	this.rtwnameHashMap["<S10>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:2"] = {rtwname: "<S10>/Compare"};
	this.rtwnameHashMap["<S10>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:3"] = {rtwname: "<S10>/Constant"};
	this.rtwnameHashMap["<S10>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:232:4"] = {rtwname: "<S10>/y"};
	this.rtwnameHashMap["<S11>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:1"] = {rtwname: "<S11>/u"};
	this.rtwnameHashMap["<S11>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:2"] = {rtwname: "<S11>/Compare"};
	this.rtwnameHashMap["<S11>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:3"] = {rtwname: "<S11>/Constant"};
	this.rtwnameHashMap["<S11>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:233:4"] = {rtwname: "<S11>/y"};
	this.rtwnameHashMap["<S12>/u"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:1"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:1"] = {rtwname: "<S12>/u"};
	this.rtwnameHashMap["<S12>/Compare"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:2"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:2"] = {rtwname: "<S12>/Compare"};
	this.rtwnameHashMap["<S12>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:3"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:3"] = {rtwname: "<S12>/Constant"};
	this.rtwnameHashMap["<S12>/y"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:4"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:234:4"] = {rtwname: "<S12>/y"};
	this.rtwnameHashMap["<S13>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:237"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:237"] = {rtwname: "<S13>/Enable"};
	this.rtwnameHashMap["<S13>/Help C Function Call"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:238"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:238"] = {rtwname: "<S13>/Help C Function Call"};
	this.rtwnameHashMap["<S13>/UART Tx2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:239"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:239"] = {rtwname: "<S13>/UART Tx2"};
	this.rtwnameHashMap["<S14>/Enable"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:242"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:242"] = {rtwname: "<S14>/Enable"};
	this.rtwnameHashMap["<S14>/Print the current content of the output buffer"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:243"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:243"] = {rtwname: "<S14>/Print the current content of the output buffer"};
	this.rtwnameHashMap["<S14>/Reference_FormatString"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:244"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:244"] = {rtwname: "<S14>/Reference_FormatString"};
	this.rtwnameHashMap["<S14>/UART Tx"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:245"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:245"] = {rtwname: "<S14>/UART Tx"};
	this.rtwnameHashMap["<S14>/UART Tx2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:246"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:246"] = {rtwname: "<S14>/UART Tx2"};
	this.rtwnameHashMap["<S14>/cr lf"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:247"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:247"] = {rtwname: "<S14>/cr lf"};
	this.rtwnameHashMap["<S15>/C Function Call2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:219"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:219"] = {rtwname: "<S15>/C Function Call2"};
	this.rtwnameHashMap["<S15>/Constant1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:220"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:220"] = {rtwname: "<S15>/Constant1"};
	this.rtwnameHashMap["<S15>/UART Tx1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:221"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:221"] = {rtwname: "<S15>/UART Tx1"};
	this.rtwnameHashMap["<S16>/Vdc"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:93"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:93"] = {rtwname: "<S16>/Vdc"};
	this.rtwnameHashMap["<S16>/Constant"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:260"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:260"] = {rtwname: "<S16>/Constant"};
	this.rtwnameHashMap["<S16>/MLI"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:86"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:86"] = {rtwname: "<S16>/MLI"};
	this.rtwnameHashMap["<S16>/PWM High Speed"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:103"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:103"] = {rtwname: "<S16>/PWM High Speed"};
	this.rtwnameHashMap["<S16>/Saturation"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:104"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:104"] = {rtwname: "<S16>/Saturation"};
	this.rtwnameHashMap["<S16>/Saturation1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:257"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:257"] = {rtwname: "<S16>/Saturation1"};
	this.rtwnameHashMap["<S16>/Saturation2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:258"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:258"] = {rtwname: "<S16>/Saturation2"};
	this.rtwnameHashMap["<S16>/Sum"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:261"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:261"] = {rtwname: "<S16>/Sum"};
	this.rtwnameHashMap["<S16>/int to uint"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:105"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:105"] = {rtwname: "<S16>/int to uint"};
	this.rtwnameHashMap["<S16>/int to uint1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:259"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:259"] = {rtwname: "<S16>/int to uint1"};
	this.rtwnameHashMap["<S17>/om(rad//s)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:123"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:123"] = {rtwname: "<S17>/om(rad//s)"};
	this.rtwnameHashMap["<S17>/Data Type Conversion"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:124"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:124"] = {rtwname: "<S17>/Data Type Conversion"};
	this.rtwnameHashMap["<S17>/Delay"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:125"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:125"] = {rtwname: "<S17>/Delay"};
	this.rtwnameHashMap["<S17>/Gain"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:126"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:126"] = {rtwname: "<S17>/Gain"};
	this.rtwnameHashMap["<S17>/Gain1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:127"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:127"] = {rtwname: "<S17>/Gain1"};
	this.rtwnameHashMap["<S17>/Gain2"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:128"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:128"] = {rtwname: "<S17>/Gain2"};
	this.rtwnameHashMap["<S17>/Sum"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:129"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:129"] = {rtwname: "<S17>/Sum"};
	this.rtwnameHashMap["<S17>/Sum1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:130"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:130"] = {rtwname: "<S17>/Sum1"};
	this.rtwnameHashMap["<S17>/omf (rad//s)"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:131"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:131"] = {rtwname: "<S17>/omf (rad//s)"};
	this.rtwnameHashMap["<S18>/Vdc"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:87"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:87"] = {rtwname: "<S18>/Vdc"};
	this.rtwnameHashMap["<S18>/Bias"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:255"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:255"] = {rtwname: "<S18>/Bias"};
	this.rtwnameHashMap["<S18>/Gain"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:90"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:90"] = {rtwname: "<S18>/Gain"};
	this.rtwnameHashMap["<S18>/Gain1"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:256"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:256"] = {rtwname: "<S18>/Gain1"};
	this.rtwnameHashMap["<S18>/PWM [0 PWMmax]"] = {sid: "TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:91"};
	this.sidHashMap["TPMCC_MCLV2_dsPIC33EP256MC506_V0_1:91"] = {rtwname: "<S18>/PWM [0 PWMmax]"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
